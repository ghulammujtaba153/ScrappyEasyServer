// injected.js (runs in page context)
// DOM-based WhatsApp number verification using iframe injection

(function () {
    console.log('%c[WA-CHECKER] WhatsApp verification script loaded (iframe method)', 'color: green; font-weight: 700');

    function postToContent(payload) {
        window.postMessage(Object.assign({ __WA_CHECKER__: true }, payload), window.origin || '*');
    }

    // Check number using iframe injection
    async function checkNumberViaIframe(phone) {
        const clean = String(phone).replace(/[^0-9]/g, '');
        const url = `https://web.whatsapp.com/send?phone=${clean}`;

        console.log(`[WA-CHECKER] Creating iframe for: ${url}`);

        return new Promise((resolve) => {
            // Create hidden iframe
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.style.position = 'absolute';
            iframe.style.width = '0';
            iframe.style.height = '0';
            iframe.src = url;

            let resolved = false;
            let checkTimeout;

            // Function to check iframe content
            const checkIframeContent = () => {
                if (resolved) return;

                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;

                    if (!iframeDoc || iframeDoc.readyState !== 'complete') {
                        console.log('[WA-CHECKER] Iframe still loading...');
                        return;
                    }

                    console.log('[WA-CHECKER] Iframe loaded, checking content...');

                    let exists = false;
                    let method = 'unknown';

                    // Check for error dialog in iframe
                    const dialog = iframeDoc.querySelector("div[role='dialog']");
                    if (dialog) {
                        const dialogText = dialog.innerText.toLowerCase();
                        console.log(`[WA-CHECKER] Dialog found in iframe:`, dialogText.substring(0, 100));

                        if (dialogText.includes("phone number shared via url is invalid") ||
                            dialogText.includes("not a whatsapp") ||
                            dialogText.includes("invalid") ||
                            dialogText.includes("doesn't have whatsapp")) {
                            exists = false;
                            method = 'iframe-error-dialog';
                            console.log(`%c✗ ${phone} does NOT have WhatsApp (iframe error dialog)`, 'color: red; font-weight: bold');

                            resolved = true;
                            clearTimeout(checkTimeout);
                            iframe.remove();
                            resolve({ exists, method });
                            return;
                        }
                    }

                    // Check for chat input in iframe
                    const inputSelectors = [
                        'div[contenteditable="true"][data-tab="10"]',
                        'div[contenteditable="true"][data-tab="6"]',
                        'footer div[contenteditable="true"]',
                        'div[aria-label="Type a message"]',
                        'footer[data-tab="10"]',
                        'footer[data-tab="6"]',
                        'div[data-testid="conversation-compose-box-input"]'
                    ];

                    for (const selector of inputSelectors) {
                        const inputBox = iframeDoc.querySelector(selector);
                        if (inputBox) {
                            exists = true;
                            method = `iframe-input:${selector}`;
                            console.log(`%c✓ ${phone} HAS WhatsApp (iframe input found)`, 'color: green; font-weight: bold');

                            resolved = true;
                            clearTimeout(checkTimeout);
                            iframe.remove();
                            resolve({ exists, method });
                            return;
                        }
                    }

                    // If neither found, check footer
                    const footer = iframeDoc.querySelector('footer');
                    if (footer && footer.querySelector('[contenteditable="true"]')) {
                        exists = true;
                        method = 'iframe-footer';
                        console.log(`%c✓ ${phone} HAS WhatsApp (iframe footer)`, 'color: green; font-weight: bold');
                    } else {
                        exists = false;
                        method = 'iframe-no-elements';
                        console.log(`%c⚠️ ${phone} - No elements found in iframe`, 'color: orange');
                    }

                    resolved = true;
                    clearTimeout(checkTimeout);
                    iframe.remove();
                    resolve({ exists, method });

                } catch (err) {
                    console.error('[WA-CHECKER] Error checking iframe:', err.message);

                    if (!resolved) {
                        resolved = true;
                        clearTimeout(checkTimeout);
                        iframe.remove();
                        resolve({ exists: false, method: 'iframe-error', error: err.message });
                    }
                }
            };

            // Wait for iframe to load
            iframe.onload = () => {
                console.log('[WA-CHECKER] Iframe onload fired');
                // Wait a bit for WhatsApp to render
                setTimeout(checkIframeContent, 4000);
            };

            // Timeout fallback
            checkTimeout = setTimeout(() => {
                if (!resolved) {
                    console.warn(`[WA-CHECKER] Timeout checking ${phone}`);
                    resolved = true;
                    iframe.remove();
                    resolve({ exists: false, method: 'iframe-timeout' });
                }
            }, 10000); // 10 second timeout

            // Add iframe to page
            document.body.appendChild(iframe);
        });
    }

    // Listen for messages from content script
    window.addEventListener('message', async (event) => {
        if (event.source !== window) return;
        const msg = event.data;

        if (!msg || msg.type !== 'START_WHATSAPP_CHECK') return;

        const phones = msg.phones || [];
        const sessionId = msg.sessionId || null;
        const API_BASE = msg.apiBase || null;
        const token = msg.token || null;
        const delayBetween = Number(msg.delayBetweenMs) || 2000;

        console.log(`%c[WA-CHECKER] Starting iframe-based verification for ${phones.length} numbers`, 'color: blue; font-weight: 700');
        postToContent({ type: 'STARTED', sessionId, total: phones.length });

        const results = [];

        for (let idx = 0; idx < phones.length; idx++) {
            const phone = phones[idx];
            console.log(`\n[WA-CHECKER] === Checking ${idx + 1}/${phones.length}: ${phone} ===`);

            postToContent({ type: 'PROGRESS', sessionId, total: phones.length, processed: idx });

            // Perform iframe-based check
            const result = await checkNumberViaIframe(phone);

            const out = {
                phone,
                exists: result.exists,
                method: result.method,
                unknown: false,
                error: result.error || null
            };

            results.push(out);

            // Send to backend via content script
            postToContent({
                type: 'UPDATE_BACKEND',
                sessionId,
                phone,
                exists: out.exists,
                unknown: out.unknown,
                raw: { method: out.method },
                error: out.error,
                apiBase: API_BASE,
                token
            });

            postToContent({
                type: 'RESULT',
                sessionId,
                phone: out.phone,
                exists: out.exists,
                unknown: out.unknown,
                error: out.error
            });

            // Delay between checks
            console.log(`[WA-CHECKER] Waiting ${delayBetween}ms before next check...`);
            await new Promise(r => setTimeout(r, delayBetween));
        }

        console.log('%c[WA-CHECKER] All numbers processed!', 'color: green; font-weight: 700');
        postToContent({ type: 'COMPLETE', sessionId, results });

        // Mark complete on backend
        postToContent({
            type: 'COMPLETE_BACKEND',
            sessionId,
            apiBase: API_BASE,
            token
        });
    });

    // Expose helper
    window.__WA_CHECKER__ = {
        checkNow: (phones, sessionId, apiBase, token, opts) => {
            window.postMessage({
                type: 'START_WHATSAPP_CHECK',
                phones,
                sessionId,
                apiBase,
                token,
                ...opts
            }, window.origin || '*');
        }
    };

    console.log('%c[WA-CHECKER] Ready - Using iframe injection method', 'color: green; font-weight: 700');
})();
