// organizer.js
// Lead Buddy Organizer Script
// Handles page analysis, lead organization, and authentication

console.log('[ORGANIZER] Lead Buddy script loaded');

// -------------------------------------------------------
// 1. AUTHENTICATION BRIDGE
// -------------------------------------------------------
window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const data = event.data;

    // Handle authentication from web dashboard
    if (data?.type === 'EXTENSION_AUTH' && data.token && data.user) {
        chrome.runtime.sendMessage(
            {
                type: 'AUTH_SUCCESS',
                token: data.token,
                user: data.user
            },
            () => {
                console.log('[ORGANIZER] Forwarded authentication to extension');
            }
        );
        return;
    }
});

// -------------------------------------------------------
// 2. LEAD ANALYSIS LOGIC
// -------------------------------------------------------
window.LeadBuddy = window.LeadBuddy || {};

// Helper: Extract Phone and Address
window.LeadBuddy.extractContactInfo = async function(specificLink = null) {
    // ── Phone regexes ────────────────────────────────────────────────────────
    // Single flexible pattern handles virtually any format:
    //   +1 212-355-2290  |  +44 20 7946 0958  |  (212) 355-2290  |  2123552290
    // Strategy: optional + or 00, then 2-4 digit groups separated by any separator,
    //           total digits must be 7-16 (checked after match).
    const SEP = '[\\s.\\-]?';
    const GRP = '[0-9]{1,5}';
    const PHONE_PATTERNS = [
        // +country_code [sep] (area) [sep] groups…
        new RegExp(`(?<!\\d)(\\+|00)?${GRP}${SEP}\\(?${GRP}\\)?(?:${SEP}${GRP}){1,4}(?!\\d)`),
        // plain run of digits 7-16
        /(?<!\d)[0-9]{7,16}(?!\d)/
    ];
    const UNIVERSAL_PHONE_REGEX = /(?<!\d)(?:\+|00)?[0-9][0-9\s.\-\(\)]{5,18}(?!\d)/g;

    function extractPhoneFromText(text) {
        if (!text) return '';
        
        // Clean text: replace non-breaking spaces and other noise
        const cleanText = text.replace(/[\u00A0\u1680\u180e\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]/g, ' ')
                             .replace(/·/g, ' ')
                             .replace(/\b(Open|Closed|Opens|Closes|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b/gi, '');
        
        for (const pattern of PHONE_PATTERNS) {
            const match = cleanText.match(pattern);
            if (match) {
                const phone = match[0].trim();
                const digitCount = phone.replace(/\D/g, '').length;
                if (digitCount >= 7 && digitCount <= 16) return phone;
            }
        }

        const matches = cleanText.match(UNIVERSAL_PHONE_REGEX);
        if (matches) {
            for (const match of matches) {
                const phone = match.trim();
                const digitCount = phone.replace(/\D/g, '').length;
                if (digitCount >= 7 && digitCount <= 16) return phone;
            }
        }
        return '';
    }

    

    function isLikelyAddress(text) {
        if (!text) return false;
        const addressKeywords = /\b(street|st|avenue|ave|road|rd|boulevard|blvd|drive|dr|lane|ln|way|place|pl|court|ct|square|sq|floor|suite|building|block|apt|apartment|city|town|province|region|district|state|zip|county|postal|united states|uk|canada|australia|germany|france|india)\b/i;
        return addressKeywords.test(text);
    }

    // Extract from the currently open detail sidebar
    // Based on exact HTML structure observed in Google Maps:
    // <button class="CsEnBe" aria-label="Phone: +1 212-355-2290" data-item-id="phone:tel:+12123552290">
    //   <div class="rogA2c">
    //     <div class="Io6YTe fontBodyMedium kR99db ...">+1 212-355-2290</div>
    //   </div>
    // </button>
    function extractFromSidebar() {
        // Try all common sidebar root selectors
        const sidebar = document.querySelector('.bJz9P, .m6QEf[role="main"], [role="region"].m6QEf, .section-layout');
        if (!sidebar) return null;

        const title = sidebar.querySelector('h1.DUwDvf, .fontHeadlineLarge, .section-hero-header-title-description')?.textContent?.trim();
        let phone = '';
        let address = '';
        let website = '';
        let rating = '';
        let reviewCount = '';

        // Rating
        const ratingEl = sidebar.querySelector('[aria-label*="stars"]');
        if (ratingEl) {
            const aria = ratingEl.getAttribute("aria-label") || "";
            const rate = aria.match(/^([\d.]+)/);
            if (rate) rating = rate[1];

            const revs = aria.match(/(\d[\d,]*)\s*reviews/i) || aria.match(/\((\d[\d,]*)\)/);
            if (revs) reviewCount = revs[1].replace(/,/g, '');
        }

        // ---- PHONE - Exact selectors from HTML inspection ----

        // Strategy A: Button with data-item-id="phone:tel:..." (most reliable)
        // The data-item-id itself contains the raw phone number after 'phone:tel:'
        const phoneButton = sidebar.querySelector('button[data-item-id^="phone:tel:"]');
        if (phoneButton) {
            // Extract directly from data-item-id attribute - the cleanest value
            const rawId = phoneButton.getAttribute('data-item-id') || '';
            const rawPhone = rawId.replace('phone:tel:', '').trim();
            if (rawPhone) {
                phone = rawPhone; // e.g. "+12123552290"
            }
            // Also try aria-label which usually has formatted version: "Phone: +1 212-355-2290"
            if (!phone) {
                const ariaLabel = phoneButton.getAttribute('aria-label') || '';
                const ariaPhone = ariaLabel.replace(/^Phone:\s*/i, '').trim();
                if (ariaPhone) phone = ariaPhone;
            }
            // Also try the visible text inside .rogA2c > .Io6YTe
            if (!phone) {
                const textEl = phoneButton.querySelector('.rogA2c .Io6YTe, .Io6YTe, .fontBodyMedium');
                if (textEl) phone = textEl.textContent?.trim();
            }
        }

        // Strategy B: Any button whose aria-label starts with "Phone:"
        if (!phone) {
            const allBtns = sidebar.querySelectorAll('button[aria-label]');
            for (const btn of allBtns) {
                const aria = btn.getAttribute('aria-label') || '';
                if (/^Phone:/i.test(aria)) {
                    phone = aria.replace(/^Phone:\s*/i, '').trim();
                    break;
                }
            }
        }

        // Strategy C: Look for .rogA2c container which holds the phone text row
        if (!phone) {
            const rogEls = sidebar.querySelectorAll('.rogA2c');
            for (const row of rogEls) {
                // Find the text inside - it's in .Io6YTe class
                const textEl = row.querySelector('.Io6YTe');
                if (textEl) {
                    const p = extractPhoneFromText(textEl.textContent || '');
                    if (p) { phone = p; break; }
                }
            }
        }

        // Strategy D: Scan all .Io6YTe elements for phone patterns
        if (!phone) {
            const ioEls = sidebar.querySelectorAll('.Io6YTe');
            for (const el of ioEls) {
                const p = extractPhoneFromText(el.textContent || '');
                if (p) { phone = p; break; }
            }
        }

        // ---- ADDRESS ----
        const addrButton = sidebar.querySelector('button[data-item-id="address"]');
        if (addrButton) {
            const textEl = addrButton.querySelector('.rogA2c .Io6YTe, .Io6YTe');
            address = textEl?.textContent?.trim() || addrButton.textContent?.trim();
        }
        if (!address) {
            const addrEl = sidebar.querySelector('[data-item-id="address"], [aria-label*="Address"], [data-tooltip*="Address"]');
            if (addrEl) address = addrEl.textContent?.trim();
        }
        if (!address) {
            const ioEls = sidebar.querySelectorAll('.Io6YTe, .fontBodyMedium');
            for (const el of ioEls) {
                if (isLikelyAddress(el.textContent)) {
                    address = el.textContent.trim();
                    break;
                }
            }
        }

        // ---- WEBSITE ----
        const webEl = sidebar.querySelector('[data-item-id="authority"], [aria-label*="Website"], a[data-item-id*="website"]');
        if (webEl) {
            website = webEl.getAttribute('href') || webEl.textContent?.trim();
        }

        return { title, phone, address, website, rating, reviewCount };
    }

    const currentSidebarData = extractFromSidebar();

    const links = specificLink ? [specificLink] : Array.from(
        document.querySelectorAll('a[href*="/maps/place/"]')
    );

    return Promise.all(links.map(async (link) => {
        const container = link.closest('[jsaction*="mouseover:pane"]');
        const titleText = container?.querySelector(".fontHeadlineSmall, .qBF1Pd")?.textContent?.trim();

        // If sidebar title matches this item, use sidebar data prioritized
        if (currentSidebarData && titleText && (currentSidebarData.title === titleText || titleText.includes(currentSidebarData.title) || currentSidebarData.title.includes(titleText))) {
            return {
                title: titleText,
                rating: currentSidebarData.rating,
                reviewCount: currentSidebarData.reviewCount,
                phone: currentSidebarData.phone,
                industry: "",
                address: currentSidebarData.address,
                companyUrl: currentSidebarData.website,
                href: link.href
            };
        }

        // List item extraction logic
        let rating = "";
        let reviewCount = "";
        let industry = "";
        let address = "";
        let phone = "";
        let companyUrl = "";

        const roleImg = container?.querySelector('[role="img"]');
        if (roleImg) {
            const aria = roleImg.getAttribute("aria-label");
            if (aria && aria.includes("stars")) {
                const parts = aria.split(" ");
                rating = parts[0];
                reviewCount = parts[2]?.replace(/\D/g, '');
            }
        }

        // Phone — 1. Best source: data-item-id
        const phoneBtn = container?.querySelector('[data-item-id^="phone:tel:"]');
        if (phoneBtn) {
            const raw = phoneBtn.getAttribute("data-item-id");
            phone = raw.replace("phone:tel:", "");
        }

        // 2. aria-label fallback
        if (!phone) {
            const aria = container?.querySelector('[aria-label*="Phone"]');
            if (aria) {
                phone = extractPhoneFromText(aria.getAttribute("aria-label"));
            }
        }

        // 3. visible text fallback
        if (!phone) {
            phone = extractPhoneFromText(container?.textContent || '');
        }

        // Address
        if (!address && container) {
             const textNodes = container.querySelectorAll('.W4Efsd > span > span');
             for (const span of textNodes) {
                 if (isLikelyAddress(span.textContent)) { address = span.textContent.trim(); break; }
             }
        }

        // Website — filter out Google-internal links to only capture genuine business URLs
        function isExternalBusinessUrl(href) {
            if (!href) return false;
            try {
                const u = new URL(href);
                const dominated = /google\.(com|[a-z]{2}(\.[a-z]{2})?)$/i.test(u.hostname);
                if (dominated) return false;
                if (/^(accounts|maps|www)\.google\./i.test(u.hostname)) return false;
            } catch { return false; }
            return true;
        }
        const urls = Array.from(container?.querySelectorAll("a[href]") || []);
        const external = urls.find((a) => isExternalBusinessUrl(a.href));
        companyUrl = external?.href || "";

        return {
            title: titleText || "",
            rating,
            reviewCount,
            phone,
            industry,
            address,
            companyUrl,
            href: link.href
        };
    }));
};

// ── Direct page reader — scoped to the detail panel ─────────────────────────
// Called right after clicking a result. Scopes ALL queries to the detail panel
// element to avoid reading stale phone numbers from left-side list cards.
window.LeadBuddy.readSidebarNow = function(titleHint) {

    // ── Locate the detail panel ───────────────────────────────────────────────
    // The panel is identified by role="main", or by class .bJz9P/.m6QEf.
    // We must NOT use document.querySelector for phone/address/website because
    // left-panel list cards also contain [data-item-id^="phone:tel:"] buttons
    // and those stale buttons get matched first, producing wrong numbers.
    const panel = (() => {
        // Prefer the element whose role="main" contains the h1 title
        const h1 = document.querySelector('h1.DUwDvf, h1.fontHeadlineLarge');
        if (h1) {
            let el = h1.parentElement;
            while (el && el !== document.body) {
                if (el.getAttribute('role') === 'main' ||
                    el.classList.contains('bJz9P') ||
                    el.classList.contains('m6QEf')) return el;
                el = el.parentElement;
            }
        }
        // Fallback selectors
        return document.querySelector('.m6QEf[role="main"]')
            || document.querySelector('.bJz9P')
            || document; // last resort
    })();

    // ── Shared phone regex ────────────────────────────────────────────────────
    const PHONE_RE = /(?<!\d)(\+|00)?[0-9]{1,5}[\s.\-]?\(?[0-9]{1,5}\)?(?:[\s.\-]?[0-9]{1,5}){1,5}(?!\d)/g;
    function cleanPhone(text) {
        if (!text) return '';
        text = text
            .replace(/[\u00A0\u1680\u2000-\u200a\u202f\u205f\u3000]/g, ' ')
            .replace(/·|\|/g, ' ')
            .replace(/\b(Open|Closed|Opens|Closes|Mon|Tue|Wed|Thu|Fri|Sat|Sun|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b/gi, '');
        const candidates = text.match(PHONE_RE) || [];
        for (const c of candidates) {
            const digits = c.replace(/\D/g, '').length;
            if (digits >= 7 && digits <= 16) return c.trim();
        }
        return '';
    }

    let phone = '', address = '', website = '', title = '', rating = '', reviewCount = '';

    // ── TITLE ─────────────────────────────────────────────────────────────────
    title = panel.querySelector('h1.DUwDvf, h1.fontHeadlineLarge, h1')?.textContent?.trim() || titleHint || '';

    // ── RATING & REVIEWS ──────────────────────────────────────────────────────
    const ratingEl = panel.querySelector('[aria-label*="stars"]');
    if (ratingEl) {
        const aria = ratingEl.getAttribute('aria-label') || '';
        const rate = aria.match(/^([\d.]+)/);
        if (rate) rating = rate[1];

        const revs = aria.match(/(\d[\d,]*)\s*reviews/i) || aria.match(/\((\d[\d,]*)\)/);
        if (revs) reviewCount = revs[1].replace(/,/g, '');
    }

    // ── PHONE — scoped to detail panel only ──────────────────────────────────

    // Method 1 (BEST): button whose data-item-id encodes the raw number
    //   data-item-id="phone:tel:+12123552290"
    const phoneBtn = panel.querySelector('button[data-item-id^="phone:tel:"]');
    if (phoneBtn) {
        const rawId  = phoneBtn.getAttribute('data-item-id') || '';
        const rawNum = rawId.replace('phone:tel:', '').trim();
        const ariaLbl = (phoneBtn.getAttribute('aria-label') || '').replace(/^Phone[:\s]*/i, '').trim();
        const innerTxt = phoneBtn.querySelector('.Io6YTe, .rogA2c .Io6YTe, .fontBodyMedium')?.textContent?.trim() || '';
        phone = rawNum || ariaLbl || cleanPhone(innerTxt);
        console.log('[ORGANIZER] ✅ Phone (data-item-id):', phone);
    }

    // Method 2: any button whose aria-label begins "Phone:"
    if (!phone) {
        for (const btn of panel.querySelectorAll('button[aria-label]')) {
            const lbl = btn.getAttribute('aria-label') || '';
            if (/^Phone[:\s]/i.test(lbl)) {
                phone = lbl.replace(/^Phone[:\s]*/i, '').trim();
                console.log('[ORGANIZER] ✅ Phone (aria-label):', phone);
                break;
            }
        }
    }

    // Method 3: .rogA2c info rows — scan each row's .Io6YTe text for a phone
    if (!phone) {
        for (const row of panel.querySelectorAll('.rogA2c')) {
            const txt = row.querySelector('.Io6YTe')?.textContent?.trim() || '';
            const p = cleanPhone(txt);
            if (p) { phone = p; console.log('[ORGANIZER] ✅ Phone (.rogA2c):', phone); break; }
        }
    }

    // Method 4: scan every .Io6YTe in the panel
    if (!phone) {
        for (const el of panel.querySelectorAll('.Io6YTe')) {
            const p = cleanPhone(el.textContent || '');
            if (p) { phone = p; console.log('[ORGANIZER] ✅ Phone (.Io6YTe scan):', phone); break; }
        }
    }

    // Method 5: catch-all — any [data-item-id] in the panel with phone/tel
    if (!phone) {
        for (const el of panel.querySelectorAll('[data-item-id]')) {
            const id  = el.getAttribute('data-item-id') || '';
            const lbl = el.getAttribute('aria-label')    || '';
            if (/phone|tel/i.test(id) || /^Phone/i.test(lbl)) {
                const p = cleanPhone(lbl) || cleanPhone(el.textContent || '') ||
                          cleanPhone(id.replace(/^phone:tel:/i, ''));
                if (p) { phone = p; console.log('[ORGANIZER] ✅ Phone ([data-item-id]):', phone); break; }
            }
        }
    }

    if (!phone) console.warn('[ORGANIZER] ❌ Phone NOT found for:', titleHint);

    // ── ADDRESS ───────────────────────────────────────────────────────────────
    const addrBtn = panel.querySelector('button[data-item-id="address"]');
    if (addrBtn) address = addrBtn.querySelector('.Io6YTe')?.textContent?.trim() || addrBtn.textContent?.trim() || '';
    if (!address) address = panel.querySelector('[data-item-id="address"]')?.textContent?.trim() || '';

    // ── WEBSITE — multi-stage ─────────────────────────────────────────────────
    function normalizeUrl(url) {
        if (!url) return '';
        url = url.trim();
        const googleRedirect = url.match(/[?&]q=([^&]+)/);
        if (googleRedirect) {
            try { url = decodeURIComponent(googleRedirect[1]); } catch (e) {}
        }
        if (url && !url.startsWith('http') && !url.startsWith('//')) url = 'https://' + url;
        if (url.startsWith('//')) url = 'https:' + url;
        return url;
    }

    // Method 1: button[data-item-id="authority"] with href in the panel
    const authorityBtn = panel.querySelector('button[data-item-id="authority"][href]');
    if (authorityBtn) {
        website = normalizeUrl(authorityBtn.getAttribute('href'));
        console.log('[ORGANIZER] ✅ Website (authority btn href):', website);
    }

    // Method 2: any [data-item-id="authority"] in the panel
    if (!website) {
        const authorityEl = panel.querySelector('[data-item-id="authority"]');
        if (authorityEl) {
            website = normalizeUrl(authorityEl.getAttribute('href') || '') ||
                      normalizeUrl(authorityEl.querySelector('.Io6YTe')?.textContent?.trim() || '') ||
                      normalizeUrl(authorityEl.textContent?.trim() || '');
            if (website) console.log('[ORGANIZER] ✅ Website (authority el):', website);
        }
    }

    // Method 3: button/a with aria-label starting "Website:"
    if (!website) {
        for (const btn of panel.querySelectorAll('button[aria-label], a[aria-label]')) {
            const lbl = btn.getAttribute('aria-label') || '';
            if (/^Website[:\s]/i.test(lbl)) {
                website = normalizeUrl(btn.getAttribute('href') || '') ||
                          normalizeUrl(lbl.replace(/^Website[:\s]*/i, '').trim()) ||
                          normalizeUrl(btn.querySelector('.Io6YTe')?.textContent?.trim() || '');
                if (website) { console.log('[ORGANIZER] ✅ Website (aria-label):', website); break; }
            }
        }
    }

    // Method 4: data-tooltip with "website"
    if (!website) {
        const tooltipEl = panel.querySelector('[data-tooltip="Open website"][href], [data-tooltip*="website" i][href]');
        if (tooltipEl) {
            website = normalizeUrl(tooltipEl.getAttribute('href'));
            if (website) console.log('[ORGANIZER] ✅ Website (data-tooltip):', website);
        }
    }

    // Method 5: .rogA2c row whose text looks like a domain
    if (!website) {
        const domainRe = /^(https?:\/\/)?([a-z0-9\-]+\.)+[a-z]{2,}(\/\S*)?$/i;
        for (const row of panel.querySelectorAll('.rogA2c')) {
            const txt = row.querySelector('.Io6YTe')?.textContent?.trim() || '';
            if (txt && domainRe.test(txt) && !txt.match(/^\+?[\d\s\-\(\)]+$/)) {
                website = normalizeUrl(txt);
                if (website) { console.log('[ORGANIZER] ✅ Website (.rogA2c domain text):', website); break; }
            }
        }
    }

    if (!website) console.warn('[ORGANIZER] ❌ Website NOT found for:', titleHint);

    console.log('[ORGANIZER] Result →', { title, phone, address, website });
    return { title, phone, address, website, rating, reviewCount };
};


// -------------------------------------------------------
// 3. AUTO SCROLL & EXTRACTION
// -------------------------------------------------------
// (window.LeadBuddy namespace already created above)

// Stop signal handling
if (typeof window.forceStopScraping === 'undefined') {
    window.forceStopScraping = false;
    
    chrome.storage.onChanged.addListener((changes) => {
        if (changes.shouldStopScraping?.newValue === true) {
            window.forceStopScraping = true;
            console.log('[ORGANIZER] 🛑 Stop signal received via storage event.');
        }
    });
}

/**
 * A cancellable sleep that checks the stop signal frequently
 */
async function cancellableWait(ms) {
    const start = Date.now();
    let lastStorageCheck = 0; // timestamp of last direct storage poll
    while (Date.now() - start < ms) {
        if (window.forceStopScraping) return true;
        
        // Fallback: direct storage check every ~500ms (using timestamp, not modulo)
        const now = Date.now();
        if (now - lastStorageCheck >= 500) {
            lastStorageCheck = now;
            const { shouldStopScraping } = await chrome.storage.local.get("shouldStopScraping");
            if (shouldStopScraping) {
                window.forceStopScraping = true;
                return true;
            }
        }
        
        await new Promise(r => setTimeout(r, 100));
    }
    return window.forceStopScraping;
}

window.LeadBuddy.autoScrollAndExtract = async function(maxResults = 1000) {
    console.log(`[ORGANIZER] Starting hybrid extract (fast-path if phone in card, click-path if not). Limit: ${maxResults}`);
    forceStopScraping = false; // Reset local flag

    const results = [];
    const seenTitles = new Set();
    
    // Initial check
    const { shouldStopScraping: initialStop } = await chrome.storage.local.get("shouldStopScraping");
    if (initialStop) return [];

    // Find the scrollable results list container
    const getScrollContainer = () => {
        return document.querySelector('div[role="feed"]')
            || Array.from(document.querySelectorAll('.m6QErb, .m6QEf'))
                .find(el => el.scrollHeight > el.clientHeight && el.offsetParent !== null)
            || document.querySelector('.section-layout-root')
            || document.querySelector('.section-scrollbox');
    };

    let scrollContainer = getScrollContainer();

    if (!scrollContainer) {
        console.error('[ORGANIZER] No scrollable list found.');
        return await window.LeadBuddy.extractContactInfo();
    }

    // ── Hoisted helpers (defined once, not per-iteration) ────────────────

    /**
     * Returns true if the text is PURELY a phone number (digits + formatting only).
     * Eliminates false positives like ratings ("4.9"), review counts ("1,631"), etc.
     */
    function isPurePhone(str) {
        if (!str) return false;
        // Strip all phone-formatting chars AND common Google Maps separators (· • | :)
        const stripped = str.replace(/[\s+\-()\\./·•|:,]/g, '');
        return /^\d+$/.test(stripped) && stripped.length >= 7 && stripped.length <= 16;
    }

    /**
     * Returns true if the href points to a genuine external business website
     * (not a google.com internal URL). Also unwraps Google redirect URLs.
     */
    function isExternalBusinessUrl(href) {
        if (!href) return false;
        try {
            const u = new URL(href);
            // Exclude all google.* domains (maps, accounts, search, etc.)
            if (/google\.(com|[a-z]{2}(\.[a-z]{2})?)$/i.test(u.hostname)) return false;
        } catch { return false; }
        return true;
    }

    /**
     * Unwrap Google redirect URLs (e.g. google.com/url?q=https://business.com)
     * and return the final destination, or the original href if not a redirect.
     */
    function unwrapGoogleRedirect(href) {
        if (!href) return '';
        try {
            const u = new URL(href);
            if (/google\./i.test(u.hostname)) {
                const q = u.searchParams.get('q') || u.searchParams.get('url');
                if (q && /^https?:\/\//i.test(q)) return q;
            }
        } catch {}
        return href;
    }

    let lastHeight = scrollContainer.scrollHeight;
    let sameHeightCount = 0;
    let isEnd = false;

    while (results.length < maxResults && !isEnd && !forceStopScraping) {
        // Gather all result cards currently in DOM
        const items = Array.from(
            document.querySelectorAll('a[href*="/maps/place/"]')
        )
        .map(link => ({ link, container: link.closest('[jsaction*="mouseover:pane"]') }))
        .filter(item => item.container);

        let foundNew = false;
        let hadFastPathOnly = true;

        // Stop if the scroll container is no longer visible (user closed the results list)
        if (!scrollContainer.isConnected || scrollContainer.offsetParent === null) {
            console.log('[ORGANIZER] 🛑 Results list hidden or closed. Stopping.');
            break;
        }

        for (const item of items) {
            // Check connectivity and visibility within the inner loop
            if (forceStopScraping) break;

            // Refresh scroll container if it became stale during sidebar navigation
            if (!scrollContainer || !scrollContainer.isConnected) {
                scrollContainer = getScrollContainer();
            }

            if (!scrollContainer || scrollContainer.offsetParent === null) break;

            let titleText = item.container.querySelector('.fontHeadlineSmall, .qBF1Pd')?.textContent?.trim();
            if (!titleText) {
                const aria = item.link.getAttribute('aria-label') || '';
                titleText = aria.split('·')[0].trim();
            }
            if (!titleText || seenTitles.has(titleText)) continue;

            seenTitles.add(titleText);
            foundNew = true;

            // ── Highlight active card ──────────────────────────────────────
            item.container.style.cssText += `
                background: rgba(8, 84, 32, 0.28) !important;
                border-left: 3px solid #099e397e !important;
                box-shadow: inset 0 0 0 1px rgba(8, 84, 32, 0.15) !important;
                transition: background 0.25s ease, border 0.25s ease !important;
            `;
            item.container.setAttribute('data-lb-status', 'active');

            // Scroll card into view so user can follow progress (start = more bottom space for upcoming)
            item.container.scrollIntoView({ behavior: 'auto', block: 'start' });
            if (await cancellableWait(180)) break;

            // ── STEP 1: Card-level extraction ──────────────────────────────
            let rating = '';
            let reviewCount = '';
            const roleImg = item.container.querySelector('[role="img"]');
            if (roleImg) {
                const aria = roleImg.getAttribute('aria-label') || '';
                const rate = aria.match(/^([\d.]+)/);
                if (rate) rating = rate[1];

                const revs = aria.match(/(\d[\d,]*)\s*reviews/i) || aria.match(/\((\d[\d,]*)\)/);
                if (revs) reviewCount = revs[1].replace(/,/g, '');
            }

            // ── Card-level phone detection ─────────────────────────────────
            // isPurePhone is hoisted above the loop — no redeclaration per card

            let phone = '';

            // Method 1: data-item-id="phone:tel:..." — most reliable, set by Google
            const phoneEl = item.container.querySelector('[data-item-id^="phone:tel:"]');
            if (phoneEl) {
                const rawNum = phoneEl.getAttribute('data-item-id').replace('phone:tel:', '').trim();
                if (isPurePhone(rawNum)) phone = rawNum;
            }

            // Method 2: aria-label starting explicitly with "Phone:" — set by Google
            if (!phone) {
                for (const el of item.container.querySelectorAll('[aria-label]')) {
                    const lbl = el.getAttribute('aria-label') || '';
                    if (/^Phone[:\s]/i.test(lbl)) {
                        const extracted = lbl.replace(/^Phone[:\s]*/i, '').trim();
                        if (isPurePhone(extracted)) { phone = extracted; break; }
                    }
                }
            }

            // Method 3: span whose visible text is purely a phone number
            // Pre-clean leading separators (· • | —) that Google Maps uses between metadata chunks
            if (!phone) {
                for (const span of item.container.querySelectorAll('.Io6YTe, .fontBodyMedium, .W4Efsd span')) {
                    const raw = span.textContent?.trim() || '';
                    // Strip leading separators: "· +1 646-846-4645" → "+1 646-846-4645"
                    const txt = raw.replace(/^[·•|—–\-\s]+/, '').trim();
                    if (txt && txt.length <= 25 && isPurePhone(txt)) {
                        phone = txt;
                        console.log(`[ORGANIZER] ⚡ Phone from card span: "${phone}"`);
                        break;
                    }
                }
            }

            // Method 4: look for phone icon (img/svg with phone-related src or aria) and read adjacent text
            if (!phone) {
                const icons = item.container.querySelectorAll('img[src*="phone"], img[src*="call"], svg');
                for (const icon of icons) {
                    // Check the parent or next sibling for phone text
                    const parent = icon.closest('span, div, button');
                    if (!parent) continue;
                    const siblingText = parent.nextElementSibling?.textContent?.trim()
                                     || parent.parentElement?.textContent?.trim() || '';
                    const cleaned = siblingText.replace(/^[·•|—–\-\s]+/, '').trim();
                    if (cleaned && cleaned.length <= 25 && isPurePhone(cleaned)) {
                        phone = cleaned;
                        console.log(`[ORGANIZER] ⚡ Phone from icon-adjacent text: "${phone}"`);
                        break;
                    }
                }
            }

            // Method 5: regex scan across all .W4Efsd text chunks for phone patterns
            // This catches cases where the phone sits in a chunk like "Restaurant · +1 646-846-4645"
            if (!phone) {
                const CARD_PHONE_RE = /(?:^|[·•|\s])\s*(\+?\d[\d\s\-().]{6,18}\d)/g;
                for (const el of item.container.querySelectorAll('.W4Efsd')) {
                    const text = el.textContent || '';
                    let match;
                    while ((match = CARD_PHONE_RE.exec(text)) !== null) {
                        const candidate = match[1].trim();
                        if (isPurePhone(candidate)) {
                            phone = candidate;
                            console.log(`[ORGANIZER] ⚡ Phone from W4Efsd regex: "${phone}"`);
                            break;
                        }
                    }
                    if (phone) break;
                }
            }

            let address = '';
            for (const span of item.container.querySelectorAll('.W4Efsd > span > span, .W4Efsd span, .Io6YTe')) {
                const txt = span.textContent?.trim() || '';
                if (!txt || txt === phone) continue;
                if (/\d/.test(txt) && txt.length > 8 && !/^[\d\s\+\-\(\)\.]+$/.test(txt)) { address = txt; break; }
            }

            // Website — isExternalBusinessUrl is hoisted above the loop
            const cardUrls = Array.from(item.container.querySelectorAll('a[href]'));
            let companyUrl = '';
            for (const a of cardUrls) {
                // First try: direct external link
                if (isExternalBusinessUrl(a.href)) {
                    companyUrl = a.href;
                    break;
                }
                // Second try: Google redirect URL wrapping a business site
                const unwrapped = unwrapGoogleRedirect(a.href);
                if (unwrapped !== a.href && isExternalBusinessUrl(unwrapped)) {
                    companyUrl = unwrapped;
                    break;
                }
            }

            // ── STEP 2: Hybrid transition to detail panel ──────────────────
            if (!phone || !companyUrl) {
                hadFastPathOnly = false;
                const missingFields = [!phone && 'phone', !companyUrl && 'website'].filter(Boolean).join(' & ');
                console.log(`[ORGANIZER] Missing ${missingFields} for "${titleText}" — opening sidebar...`);

                const previousSidebarTitle = document.querySelector('h1.DUwDvf, h1.fontHeadlineLarge, h1')?.textContent?.trim() || '';
                item.link.click();
                
                    // 1. Wait for sidebar to shift to the new business
                    const pollStart = Date.now();
                    let hasMoved = false;
                    let panel = null;

                    while (Date.now() - pollStart < 5000) {
                        if (window.forceStopScraping) break;
                        
                        // Look for the specific panel element
                        panel = document.querySelector('.m6QEf[role="main"], .bJz9P, [role="main"]');
                        const currentTitle = panel?.querySelector('h1.DUwDvf, h1.fontHeadlineLarge, h1')?.textContent?.trim() || '';
                        
                        // We must see a title that matches our target lead
                        if (currentTitle && (currentTitle === titleText || titleText.includes(currentTitle) || currentTitle.includes(titleText))) {
                            hasMoved = true;
                            break;
                        }
                        await new Promise(r => setTimeout(r, 200));
                    }

                    // 2. Wait for inner detail layout to populate (Scoped to Panel)
                    if (hasMoved && panel) {
                        console.log('[ORGANIZER] Sidebar panel detected, waiting for content...');
                        const dataPollStart = Date.now();
                        
                        // Small scroll to trigger lazy-loading of details (phone is often below the fold)
                        const detailScrollBox = panel.querySelector('.m6QEf') || panel;
                        if (detailScrollBox) detailScrollBox.scrollTop = 200;

                        while (Date.now() - dataPollStart < 5000) {
                            if (window.forceStopScraping) break;
                            
                            // SCOPED queries to avoid matching background list chips
                            const hasPhone = panel.querySelector('button[data-item-id^="phone:tel:"]');
                            const hasAddr = panel.querySelector('button[data-item-id="address"]');
                            const hasWeb = panel.querySelector('[data-item-id="authority"]');
                            
                            // Break early based on what we actually need:
                            // - If we already had phone from card, we only need website
                            // - If we already had website from card, we only need phone
                            const neededPhone = !phone;
                            const neededWebsite = !companyUrl;
                            const gotNeededPhone = !neededPhone || hasPhone;
                            const gotNeededWebsite = !neededWebsite || hasWeb;
                            if (gotNeededPhone && gotNeededWebsite) break;
                            // Also break if we have enough general data
                            if (hasPhone || (hasAddr && hasWeb)) break;
                            
                            // Nudge scroll again if taking time
                            if (Date.now() - dataPollStart > 2000 && detailScrollBox) {
                                detailScrollBox.scrollTop += 300;
                            }

                            await new Promise(r => setTimeout(r, 300));
                        }
                        // One tiny final buffer for late-rendering elements
                        await new Promise(r => setTimeout(r, 600));
                    }

                // 3. Read data from sidebar
                const sd = window.LeadBuddy.readSidebarNow(titleText);
                if (sd) {
                    // Only fill in fields that were missing — never overwrite
                    // a good card-level value with an empty sidebar value
                    if (!phone && sd.phone)             phone       = sd.phone;
                    if (!address && sd.address)         address     = sd.address;
                    if (!companyUrl && sd.website)      companyUrl  = sd.website;
                    if (!rating && sd.rating)           rating      = sd.rating;
                    if (!reviewCount && sd.reviewCount) reviewCount = sd.reviewCount;
                }
                console.log(`[ORGANIZER] Detail fetch done — "${titleText}" | phone: "${phone || 'MISSING'}" | website: "${companyUrl || 'MISSING'}"`);

                // ── STEP 3: Return to list ─────────────────────────────────
                // In single-panel layout, click "Back" to restore the list
                const backBtn = document.querySelector('button[aria-label="Back"], button.hYBOP.FeXq4d');
                if (backBtn) {
                    console.log('[ORGANIZER] Clicking Back button to return to results list...');
                    backBtn.click();
                    
                    // Wait for the "Menu" icon to reappear — the definitive signal navigation is back to results
                    const backPollStart = Date.now();
                    while (Date.now() - backPollStart < 5000) {
                        if (window.forceStopScraping) break;
                        
                        scrollContainer = getScrollContainer();

                        // Check if list is back and has at least some results rendered
                        const listHasResults = document.querySelector('a[href*="/maps/place/"]');
                        if (scrollContainer && scrollContainer.isConnected && scrollContainer.offsetParent !== null && listHasResults) {
                            await new Promise(r => setTimeout(r, 800)); // Deeper buffer for cards to stabilize
                            break;
                        }
                        await new Promise(r => setTimeout(r, 200));
                    }
                    console.log('[ORGANIZER] Return to results confirmed.');
                }
            }

            // ── STEP 4: Record Results ─────────────────────────────────────
            results.push({
                title:      titleText,
                rating,
                reviewCount,
                phone,
                industry:   '',
                address,
                companyUrl,
                href:       item.link.href
            });
            console.log(`[ORGANIZER] #${results.length} "${titleText}" | phone: "${phone || 'MISSING'}" | website: "${companyUrl || 'MISSING'}"`);

            // Mark card as done visually
            item.container.setAttribute('data-lb-status', 'done');
            item.container.style.cssText = item.container.style.cssText
                .replace(/background:[^;]+;?/g, '')
                .replace(/border-left:[^;]+;?/g, '')
                .replace(/box-shadow:[^;]+;?/g, '')
                .replace(/transition:[^;]+;?/g, '');
            item.container.style.cssText += `
                background: rgba(8, 84, 32, 0.04) !important;
                border-left: 3px solid rgba(8, 84, 32, 0.25) !important;
                transition: background 0.3s ease !important;
            `;

            try {
                chrome.runtime.sendMessage({ type: 'EXTRACTION_PROGRESS', count: results.length });
            } catch (e) {}

            if (results.length >= maxResults) break;

            // ── STEP 5: Re-sync UI if needed ──────────────────────────────
            // If we opened the sidebar, the batch is now stale and we must break to refresh
            if (!hadFastPathOnly) {
                console.log('[ORGANIZER] Breaking batch to refresh stale DOM references...');
                break;
            }

            // Small pause — lets highlight render (deeper pause = more humane)
            if (await cancellableWait(250)) break;
        }

        // Scroll down to load more cards
        if (!foundNew || results.length < maxResults) {
            // If the whole batch was no-click (very fast), Google Maps hasn't had
            // time to lazy-load the next set of cards yet — give it a head-start.
            if (hadFastPathOnly && foundNew) {
                console.log('[ORGANIZER] Fast-path batch complete — pausing before scroll to let cards load...');
                if (await cancellableWait(600)) break;
            }

            scrollContainer.scrollTop = scrollContainer.scrollHeight;
            if (await cancellableWait(2000)) break; // wait for lazy-loaded cards to appear

            const newHeight = scrollContainer.scrollHeight;
            if (newHeight === lastHeight) {
                sameHeightCount++;
                // Roll back (upwards) significantly to trigger a fresh lazy-load calculation
                console.log(`[ORGANIZER] Scroll stuck at #${results.length}. Attempt ${sameHeightCount}/8. Rolling back...`);
                scrollContainer.scrollTop -= 600; 
                
                // Wait while rolled back
                await cancellableWait(1500);
                
                // Move again (back to bottom)
                scrollContainer.scrollTop = scrollContainer.scrollHeight;
                
                // Wait again to see if new items load
                await cancellableWait(200);
                
                if (sameHeightCount >= 6) isEnd = true;
            } else {
                lastHeight = newHeight;
                sameHeightCount = 0;
            }
        }

        // Check for end-of-list indicator using a cheap selector instead of
        // scanning the entire page text with innerText
        const endIndicator = document.querySelector('.HlvSq, p.fontBodyMedium');
        if (endIndicator && endIndicator.textContent.includes("reached the end")) isEnd = true;
    }

    console.log(`[ORGANIZER] Done. ${results.length} leads collected.`);
    return results;
};

window.LeadBuddy.processLeadsOnPage = async function() {
    return await window.LeadBuddy.autoScrollAndExtract(1000);
};

console.log('[ORGANIZER] Lead Buddy ready. Test sidebar: window.LeadBuddy.readSidebarNow("test")');
