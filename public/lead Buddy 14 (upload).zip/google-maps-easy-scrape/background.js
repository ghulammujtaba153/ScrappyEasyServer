// Background script to handle authentication messages from web dashboard

console.log('🚀 Extension background script loaded');

// Listen for messages from web pages (the dashboard login page)
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
    console.log('📩 External message received:', request);

    if (request.type === 'AUTH_SUCCESS') {
        // Store auth token and user data
        chrome.storage.local.set({
            authToken: request.token,
            user: request.user
        }, () => {
            console.log('✅ Authentication data saved to storage');
            sendResponse({ success: true });
        });
        return true; // Keep the message channel open for async response
    }
});

// Listen for internal extension messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('📨 Internal message received:', request);

    if (request.type === 'AUTH_SUCCESS') {
        // Store auth token and user data
        chrome.storage.local.set({
            authToken: request.token,
            user: request.user
        }, () => {
            console.log('✅ Authentication data saved');
            sendResponse({ success: true });
        });
        return true;
    }
});

// Configure the side panel to open on click
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
        .setPanelBehavior({ openPanelOnActionClick: true })
        .catch((error) => console.error('Error setting panel behavior:', error));
}

// Detect when side panel closes
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === "sidepanel") {
        console.log('✅ Side panel port connected');
        port.onDisconnect.addListener(() => {
            console.log('🛑 Side panel closed, signaling scrapper to stop');
            chrome.storage.local.set({ shouldStopScraping: true });
        });
    }
});

// Optional: Clear storage on extension install/update
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('🎉 Extension installed');
        chrome.storage.local.set({ shouldStopScraping: false });
    } else if (details.reason === 'update') {
        console.log('🔄 Extension updated');
    }
});

