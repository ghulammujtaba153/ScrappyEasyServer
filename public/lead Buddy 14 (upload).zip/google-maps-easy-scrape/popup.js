const API_BASE_URL = 'https://scrappyeasyserver.onrender.com/api';
const REGISTER_URL = 'https://app.mapharvest.live/register';
const WEB_DASHBOARD_URL = 'https://app.mapharvest.live/login?extension=true';
const DASHBOARD_LINK = 'https://app.mapharvest.live/dashboard';

// const API_BASE_URL = 'http://localhost:5000/api';
// const WEB_DASHBOARD_URL = 'http://localhost:5173/login?extension=true';
// const DASHBOARD_LINK = 'http://localhost:5173/dashboard';


let pendingExportData = [];
let exportDefaultSearch = '';
let usingNewSearchString = false;
const exportModalElements = {};
const upgradeModalElements = {};
const downloadModalElements = {};

// Persistence State
let savedLeads = [];
let currentRecommendations = null;
let isAppending = false;
let isAnalyzing = false;

/**
 * Utility to simulate human-like delays during lead organization
 */
const humanDelay = (ms) => new Promise(res => setTimeout(res, ms + Math.random() * 1000));

/**
 * Update the Export to CRM button icon based on its disabled state.
 */
function updateExportBtnIcon(btn, isSubscribed) {
    if (!btn) return;
    const icon = btn.querySelector('img.export-lock-icon');
    if (icon) {
        const locked = (isSubscribed === false) || btn.disabled;
        icon.src = locked ? 'icons/padlock.svg' : 'icons/unlock.svg';
        icon.title = (isSubscribed === false) ? 'Premium Feature — Upgrade to unlock' : (btn.disabled ? 'Locked — analyze contacts first' : 'Export to CRM');
    }
}

/* -------------------------------------------------------
   HANDLE LEAD ANALYSIS RESPONSE
   (Moved to top level to ensure availability)
------------------------------------------------------- */
function handleAnalysisResults(results, resultsTable) {
    // We clear isAnalyzing at the END to prevent UI flickering from tab listeners during processing
    // isAnalyzing = false; 

    if (chrome.runtime.lastError) {
        document.getElementById("message").textContent = "Error: " + chrome.runtime.lastError.message;
        stopAnalyzingUI();
        return;
    }

    if (!results || !results[0]) {
        document.getElementById("message").textContent = "Analysis failed or returned no data.";
        stopAnalyzingUI();
        return;
    }

    const analyzed = results[0].result;

    if (!Array.isArray(analyzed) || analyzed.length === 0) {
        document.getElementById("message").textContent = "No business contacts found. Please scroll the list on Google Maps first.";
        stopAnalyzingUI();
        return;
    }

    // Merge and deduplicate
    if (isAppending) {
        const existingTitles = new Set(savedLeads.map(item => (item.title || "").toLowerCase().trim()));
        const uniqueNew = analyzed.filter(item => {
            const title = (item.title || "").toLowerCase().trim();
            if (!title || existingTitles.has(title)) return false;
            existingTitles.add(title);
            return true;
        });
        savedLeads = [...savedLeads, ...uniqueNew];
    } else {
        // Just deduplicate the new set itself by title
        const seen = new Set();
        savedLeads = analyzed.filter(item => {
            const title = (item.title || "").toLowerCase().trim();
            if (!title || seen.has(title)) return false;
            seen.add(title);
            return true;
        });
    }

    renderResultsTable(savedLeads, resultsTable);

    // Reset flags and save
    isAppending = false;
    saveState();
    
    // Show success message
    document.getElementById("message").textContent = `✅ Saved ${savedLeads.length} unique contacts!`;
    document.getElementById("message").style.color = "#0F792C";

    // Update button states
    const exportBtn = document.getElementById("exportDbButton");
    const downloadBtn = document.getElementById("downloadCsvButton");
    if (exportBtn) {
        chrome.storage.local.get(["authToken", "user"], ({ authToken, user }) => {
            if (!user) {
                exportBtn.style.display = "none";
            } else {
                exportBtn.style.display = "block";
                const isSubscribed = user && (user.isSubscription || user.isSubscribed);
                exportBtn.disabled = !authToken || savedLeads.length === 0;
                updateExportBtnIcon(exportBtn, isSubscribed);
            }
        });
    }
    if (downloadBtn) downloadBtn.disabled = savedLeads.length === 0;

    // Show recommendations
    handleRecommendations(savedLeads);
    
    // Process complete
    stopAnalyzingUI();

    chrome.storage.local.get(["authToken"], ({ authToken }) => {
        if (!authToken) {
            const guestPromoModal = document.getElementById("guestPromoModal");
            if (guestPromoModal) guestPromoModal.style.display = "flex";
        }
    });
}

function stopAnalyzingUI() {
    isAnalyzing = false;
    const overlay = document.getElementById("analyzingOverlay");
    if (overlay) overlay.style.display = "none";
    document.body.classList.remove('no-scroll');
}

function renderResultsTable(data, resultsTable) {
    if (!resultsTable) return;
    resultsTable.innerHTML = "";

    if (!data || data.length === 0) return;

    const headers = ["Title", "Rating", "Reviews", "Phone", "Address", "Website", "Google Maps Link"];
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");
    headers.forEach((h) => {
        const th = document.createElement("th");
        th.textContent = h;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);

    const tbody = document.createElement("tbody");
    data.forEach((item) => {
        const tr = document.createElement("tr");
        ["title", "rating", "reviewCount", "phone", "address", "companyUrl", "href"].forEach((key) => {
            const td = document.createElement("td");
            let value = item[key] || "";
            // Fallback for reviewCount if labeled as reviews
            if (key === "reviewCount" && !value) value = item.reviews || "";
            td.textContent = value;
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });

    resultsTable.appendChild(thead);
    resultsTable.appendChild(tbody);

    const downBtn = document.getElementById("downloadCsvButton");
    const expBtn = document.getElementById("exportDbButton");
    const clearLink = document.getElementById("clearDataLink");
    const clearDataButton = document.getElementById("clearDataButton");

    if (downBtn) downBtn.disabled = (data.length === 0);
    if (expBtn) {
        expBtn.style.display = (data.length > 0) ? "block" : "none";
        chrome.storage.local.get(["authToken", "user"], ({ authToken, user }) => {
            const isSubscribed = user && (user.isSubscription || user.isSubscribed);
            expBtn.disabled = !authToken || (data.length === 0);
            updateExportBtnIcon(expBtn, isSubscribed);
        });
    }
    if (clearLink) clearLink.style.display = (data.length > 0) ? "block" : "none";
    if (clearDataButton) {
        clearDataButton.style.display = (data.length > 0) ? "block" : "none";
        clearDataButton.disabled = (data.length === 0);
    }
}

async function saveState() {
    await chrome.storage.local.set({
        savedLeadsPersistent: savedLeads,
        recommendationsPersistent: currentRecommendations
    });
}

async function loadPersistentState() {
    const data = await chrome.storage.local.get(["savedLeadsPersistent", "recommendationsPersistent"]);
    
    if (data.savedLeadsPersistent && data.savedLeadsPersistent.length > 0) {
        savedLeads = data.savedLeadsPersistent;
        renderResultsTable(savedLeads, document.getElementById("resultsTable"));
        
        const msgElement = document.getElementById("message");
        if (msgElement) {
            msgElement.textContent = `Restored ${savedLeads.length} contacts.`;
        }
        
        const clearLink = document.getElementById("clearDataLink");
        if (clearLink) clearLink.style.display = "block";
    }
    if (data.recommendationsPersistent) {
        currentRecommendations = data.recommendationsPersistent;
        renderRecommendations(currentRecommendations);
    }
}



async function clearAllData() {
    // Clear state variables
    savedLeads = [];
    currentRecommendations = null;
    
    // Clear storage
    await chrome.storage.local.remove(["savedLeadsPersistent", "recommendationsPersistent"]);
    
    // Clear UI
    const resultsTable = document.getElementById("resultsTable");
    if (resultsTable) resultsTable.innerHTML = "";
    
    const msg = document.getElementById("message");
    if (msg) {
        msg.textContent = "All contacts cleared.";
        msg.style.color = "";
    }
    
    const clearLink = document.getElementById("clearDataLink");
    if (clearLink) clearLink.style.display = "none";
    
    const clearDataButton = document.getElementById("clearDataButton");
    if (clearDataButton) clearDataButton.style.display = "none";
    
    const recSection = document.getElementById("recommendationsSection");
    if (recSection) recSection.style.display = "none";
    
    const appendBtn = document.getElementById("appendActionButton");
    if (appendBtn) appendBtn.style.display = "none";
    
    const exportBtn = document.getElementById("exportDbButton");
    if (exportBtn) exportBtn.style.display = "none";
    
    // Disable download button
    const downloadBtn = document.getElementById("downloadCsvButton");
    if (downloadBtn) downloadBtn.disabled = true;
}

/* -------------------------------------------------------
   HANDLE CITY RECOMMENDATIONS
------------------------------------------------------- */
async function handleRecommendations(leadData) {

    const recSection = document.getElementById("recommendationsSection");
    const recChips = document.getElementById("recommendationChips");

    if (!recSection || !recChips) return;

    // Reset state - show loading only if we have no chips or if we are refreshing
    recSection.style.display = "block";
    recChips.innerHTML = '<div class="loading" style="border-top-color: #0F792C; width: 24px; height: 24px; margin: 10px auto;"></div>';

    try {
        let searchQuery = await extractCurrentSearchQuery();
        const { user } = await chrome.storage.local.get(["user"]);
        const userId = user?.id || user?._id || "";

        if (!searchQuery) {
            recSection.style.display = "none";
            return;
        }

        let targetLoc = searchQuery;
        if (searchQuery.toLowerCase().includes(" in ")) {
            targetLoc = searchQuery.split(/ in /i).pop().trim();
        } else if (searchQuery.includes(",")) {
            targetLoc = searchQuery.split(",")[0].trim();
        }

        const url = `${API_BASE_URL}/location/smart-recommendations?q=${encodeURIComponent(targetLoc)}&userId=${userId}&limit=12`;
        const res = await fetch(url);
        const json = await res.json();

        if (json.success && json.neighbors && json.neighbors.length > 0) {
            currentRecommendations = {
                type: json.type,
                neighbors: json.neighbors,
                searchQuery: searchQuery
            };
            renderRecommendations(currentRecommendations);
            saveState(); // Save the fresh recommendations
        } else {
            recSection.style.display = "none";
            currentRecommendations = null;
            saveState();
        }
    } catch (err) {
        console.error("Failed to load recommendations:", err);
        // If we have persistent recommendations, show them as fallback
        if (currentRecommendations) {
            renderRecommendations(currentRecommendations);
        } else {
            recSection.style.display = "none";
        }
    }
}

function renderRecommendations(recData) {
    const recSection = document.getElementById("recommendationsSection");
    const recChips = document.getElementById("recommendationChips");
    if (!recSection || !recChips || !recData) return;

    recChips.innerHTML = "";
    recSection.style.display = "block";

    const neighbors = Array.isArray(recData.neighbors) ? recData.neighbors : [];
    const suggestions = neighbors.slice(0, 8);

    if (suggestions.length === 0) {
        recSection.style.display = "none";
        return;
    }

    suggestions.forEach(neighbor => {
        const chip = document.createElement("button");
        chip.className = "recommendation-chip";

        let subtitle = recData.type === "state" ? "City" : "Nearby";
        if (neighbor.already_organized) subtitle = "Organized";

        chip.title = `${neighbor.city}, ${neighbor.admin_name} (${subtitle})`;
        chip.innerHTML = `
            <svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-12-7zm0 9.5a2.5 2.5 0 010-5 2.5 2.5 0 010 5z"/></svg>
            <span>${neighbor.city}</span>
        `;

        if (neighbor.already_organized) {
            chip.style.opacity = "0.7";
            chip.style.borderStyle = "dashed";
        }

        chip.onclick = () => {
            const currentQuery = recData.searchQuery || "";
            const newQuery = currentQuery.toLowerCase().includes(" in ")
                ? currentQuery.replace(/ in .*/i, ` in ${neighbor.city}`)
                : `${neighbor.city}`;

            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const tab = tabs[0];
                if (tab) {
                    const encodeQuery = encodeURIComponent(newQuery);
                    const newUrl = `https://www.google.com/maps/search/${encodeQuery}`;
                    chrome.tabs.update(tab.id, { url: newUrl });

                    // Visual feedback only - do NOT save "Navigating..." to state
                    chip.style.background = "#0F792C";
                    chip.style.color = "white";
                    chip.innerHTML = '<div class="loading" style="width: 14px; height: 14px; margin: 0; border-top-color:white; border-width: 2px;"></div>';
                }
            });
        };
        recChips.appendChild(chip);
    });
}

/* -------------------------------------------------------
   INITIALIZE POPUP
------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", async () => {
    try {
        setupExportModal();
        setupUpgradeModal();
        setupDownloadModal();
        setupGuestPromoModal();
        await loadPersistentState(); // Load data first for background readiness
        setupPersistenceHandlers();
        
        // Initialize Splash Screen Flow
        initSplashScreen();

        // Open port to background to detect closure
        const port = chrome.runtime.connect({ name: "sidepanel" });

        // Kill any scraping session that was running before this panel opened/reopened.
        // Set the stop flag first so the organizer.js storage.onChanged listener can
        // react and break out of any active scroll/click loop, then clear it so fresh
        // analyses can start normally.
        await chrome.storage.local.set({ shouldStopScraping: true });
        await new Promise(resolve => setTimeout(resolve, 350)); // give organizer.js time to react
        await chrome.storage.local.set({ shouldStopScraping: false });

        // Listen for tab updates to refresh UI after navigation completes
        chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
            if (changeInfo.status === 'complete') {
                // Ensure we only update for the active tab to avoid unnecessary refreshes
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    const activeTab = tabs[0];
                    if (activeTab && activeTab.id === tabId && !isAnalyzing) {
                        chrome.storage.local.get(["user"], ({ user }) => {
                            // Always refresh UI state when tab completes loading
                            initializeLeadOrganizer(user);
                        });
                    }
                });
            }
        });

        // Listen for tab switching to refresh UI state
        chrome.tabs.onActivated.addListener(() => {
            if (!isAnalyzing) {
                chrome.storage.local.get(["user"], ({ user }) => {
                    // Always refresh UI state when switching tabs
                    initializeLeadOrganizer(user);
                });
            }
        });
    } catch (error) {
        console.error("Popup Initialization Failed:", error);
        // Fallback?
    }
});

/* -------------------------------------------------------
   SPLASH & AUTH FLOW
------------------------------------------------------- */
function initSplashScreen() {
    const splashScreen = document.getElementById("splash-screen");
    const authScreen = document.getElementById("auth-screen");
    const appScreen = document.getElementById("app-screen");
    
    // Ensure correct initial visibility
    if (splashScreen) splashScreen.style.display = "flex";
    if (authScreen) authScreen.style.display = "none";
    if (appScreen) appScreen.style.display = "none";

    const continueBtn = document.getElementById("splashContinueButton");
    if (continueBtn) {
        continueBtn.onclick = handleSplashContinue;
    }
    
    // Setup Auth Screen Buttons
    const continueFreeBtn = document.getElementById("continueFreeButton");
    const signInBtn = document.getElementById("signInButton");
    
    if (continueFreeBtn) {
        continueFreeBtn.onclick = () => {
            showAppScreen(null);
        };
    }
    
    if (signInBtn) {
        signInBtn.onclick = () => {
             // Logic from original login button
            let loginUrl = WEB_DASHBOARD_URL;
            if (!loginUrl.includes("/login")) {
                loginUrl = `${loginUrl}/login?extension=true`;
            } else if (!loginUrl.includes("extension=true")) {
                loginUrl += (loginUrl.includes("?") ? "&" : "?") + "extension=true";
            }
            chrome.tabs.create({ url: loginUrl });
        };
    }
}

async function handleSplashContinue() {
    const splashButton = document.getElementById("splashContinueButton");
    if (splashButton) {
        splashButton.textContent = "Checking...";
        splashButton.disabled = true;
    }

    try {
        const { authToken, user } = await chrome.storage.local.get(["authToken", "user"]);
        
        if (authToken && user) {
            // Verify token before proceeding
            await verifyToken(authToken, user, true); // true = from splash
        } else {
            showAuthScreen();
        }
    } catch (err) {
        console.error("Auth check error:", err);
        showAuthScreen();
    }
}

function showAuthScreen() {
    document.getElementById("splash-screen").style.display = "none";
    document.getElementById("app-screen").style.display = "none";
    document.getElementById("auth-screen").style.display = "flex";
}

function showAppScreen(user) {
    document.getElementById("splash-screen").style.display = "none";
    document.getElementById("auth-screen").style.display = "none";
    document.getElementById("app-screen").style.display = "block";
    
    // Initialize the main app UI
    showLoggedInUI(user);
    initializeLeadOrganizer(user);
}

function setupPersistenceHandlers() {
    const appendBtn = document.getElementById("appendActionButton");
    const clearLink = document.getElementById("clearDataLink");
    const resultsTable = document.getElementById("resultsTable");

    if (appendBtn) {
        appendBtn.onclick = () => {
            isAppending = true;
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]?.id) analyzePageForLeads(tabs[0].id, resultsTable);
            });
        };
    }

    if (clearLink) {
        clearLink.onclick = async (e) => {
            e.preventDefault();
            if (confirm("Clear all scraped results?")) {
                await clearAllData();
            }
        };
    }
}

async function loadAuthState() {
    try {
        const { authToken, user } = await chrome.storage.local.get(["authToken", "user"]);
        
        // Remove the "Checking authentication..." placeholder now that we have local state
        const msg = document.getElementById("message");
        if (msg && msg.textContent === "Checking authentication...") {
            msg.textContent = "";
        }

        if (authToken && user) {
            showLoggedInUI(user);
            initializeLeadOrganizer();
            verifyToken(authToken, user);
        } else {
            showGuestModeUI();
        }
    } catch (err) {
        console.error("loadAuthState failed:", err);
        showGuestModeUI();
    }
}

/* -------------------------------------------------------
   SHOW GUEST MODE UI (Free Version)
------------------------------------------------------- */
function showGuestModeUI() {
    // In new flow, Guest Mode UI is effectively the Auth Screen?
    // Or if we call this from logout, we go back to Auth Screen.
    showAuthScreen();
}



/* -------------------------------------------------------
   SHOW LOGGED OUT UI (For backward compatibility)
------------------------------------------------------- */
function showLoggedOutUI() {
    showGuestModeUI();
}

/* -------------------------------------------------------
   LOGIN
------------------------------------------------------- */
const loginBtn = document.getElementById("loginButton");
if (loginBtn) {
    loginBtn.addEventListener("click", () => {
        let loginUrl = WEB_DASHBOARD_URL;
        // If the constant doesn't already contain /login, append it
        if (!loginUrl.includes("/login")) {
            loginUrl = `${loginUrl}/login?extension=true`;
        } else if (!loginUrl.includes("extension=true")) {
            // If it has /login but missing the flag, append the flag correctly
            loginUrl += (loginUrl.includes("?") ? "&" : "?") + "extension=true";
        }
        
        chrome.tabs.create({ url: loginUrl });
    });
}

/* -------------------------------------------------------
   LOGOUT
------------------------------------------------------- */
const logoutBtn = document.getElementById("logoutButton");
if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
        chrome.storage.local.remove(["authToken", "user"], () => {
            showGuestModeUI();
        });
    });
}

/* -------------------------------------------------------
   VERIFY TOKEN
------------------------------------------------------- */
async function verifyToken(token, user, isSplash = false) {
    try {
        const res = await fetch(`${API_BASE_URL}/auth/verifyToken`, {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` }
        });

        if (!res.ok) {
            throw new Error(res.statusText);
        }

        const data = await res.json();
        
        // Persist verified user (ensures subscription status is up to date in storage)
        if (data.user) {
            await chrome.storage.local.set({ user: data.user });
        }
        
        if (isSplash) {
            showAppScreen(data.user);
        } else {
            showLoggedInUI(data.user);
            initializeLeadOrganizer(data.user);
        }

    } catch (err) {
        console.warn("Token verification failed:", err.message);
        
        // If the server is unreachable, just proceed with the cached user 
        // instead of abruptly logging them out.
        if (err.message === "Failed to fetch" && user) {
            console.warn("Server unreachable, continuing in offline mode.");
            if (isSplash) {
                showAppScreen(user);
            } else {
                showLoggedInUI(user);
                initializeLeadOrganizer(user);
            }
            return;
        }

        await chrome.storage.local.remove(["authToken", "user"]);
        
        if (isSplash) {
            showAuthScreen();
        } else {
            showLoggedOutUI(); // Should redirect to auth screen
        }
    }
}

/* -------------------------------------------------------
   SHOW LOGGED IN UI
------------------------------------------------------- */
function showLoggedInUI(user) {
    const loginBtn = document.getElementById("loginButton");
    const logoutBtn = document.getElementById("logoutButton");
    const userInfo = document.getElementById("userInfo");

    if (loginBtn) loginBtn.style.display = "none";
    if (logoutBtn) logoutBtn.style.display = "block";

    const exportBtn = document.getElementById("exportDbButton");
    if (exportBtn) {
        exportBtn.disabled = false;
        exportBtn.style.display = "block";
        const isSubscribed = user && user.isSubscription;
        updateExportBtnIcon(exportBtn, isSubscribed);
    }

    // Clear guest info/header user info as we now show it centered in the message area when not on Maps
    // Or keep it minimal in the header. The user specifically asked for "on top of btn in center"
    if (userInfo) {
        // We will let initializeLeadOrganizer handle this
    }
}

/* -------------------------------------------------------
   INITIALIZE LEAD ORGANIZER LOGIC
------------------------------------------------------- */
async function initializeLeadOrganizer(user) {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        const tab = tabs[0];
        const url = tab?.url || "";

        const actionButton = document.getElementById("actionButton");
        const downloadCsvButton = document.getElementById("downloadCsvButton");
        const exportDbButton = document.getElementById("exportDbButton");
        const filenameInput = document.getElementById("filenameInput");
        const resultsTable = document.getElementById("resultsTable");
        const msg = document.getElementById("message");
        
        // Subscription Check
        const isSubscribed = user && (user.isSubscription || user.isSubscribed);

        

        /* ---------------------------
           Check if user is on Maps or Local Search
        --------------------------- */
        if (url.includes("google.com/maps") || (url.includes("google.com/search") && (url.includes("tbm=lcl") || url.includes("maps")))) {
            // WE ARE ON MAPS: Show Lead Buddy controls
            
            let userProfileHtml = '';
            if (user) {
                userProfileHtml = `
                    <div style="margin: 0 auto 20px; max-width: 280px; text-align: center; padding-bottom: 15px; border-bottom: 1px solid #f0f0f0;">
                         <div style="width: 60px; height: 60px; background: #fdfdfb; border: 4.5px solid #0F792C; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; box-shadow: 0 4px 12px rgba(15, 121, 44, 0.1); padding: 2px; overflow: hidden;">
                            <img src="/icons/avatar.png" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; object-position: center 1px;">
                        </div>
                        <h4 style="font-size: 15px; color: #1a202c; margin: 0; font-weight: 700;">${user.name || "Lead Buddy User"}</h4>
                        <p style="font-size: 12px; color: #718096; margin: 2px 0 10px;">${user.email}</p>
                        <p style="font-size: 11px; color: ${isSubscribed ? '#0F792C' : '#e53e3e'}; font-weight: 600; margin-bottom: 8px;">
                            ${isSubscribed ? 'Premium Plan' : 'Free Plan'}
                        </p>
                        <button id="inlineLogout" style="background: none; border: none; color: #ff4444; font-size: 11px; font-weight: 600; cursor: pointer; text-decoration: underline; padding: 0;">Logout</button>
                    </div>
                `;
            } else {
                userProfileHtml = `
                    <div style="margin: 0 auto 20px; max-width: 280px; text-align: center; padding-bottom: 15px; border-bottom: 1px solid #f0f0f0;">
                         <div style="width: 60px; height: 60px; background: #fdfdfb; border: 4.5px solid #0F792C; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; box-shadow: 0 4px 12px rgba(15, 121, 44, 0.1); padding: 2px; overflow: hidden;">
                            <img src="/icons/avatar.png" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; object-position: center 1px;">
                        </div>
                        <h4 style="font-size: 15px; color: #1a202c; margin: 0; font-weight: 700;">Guest User</h4>
                        <p style="font-size: 11px; color: #718096; font-weight: 600; margin-bottom: 8px; margin-top: 5px;">
                            Free Plan
                        </p>
                        <button id="inlineLogout" style="background: none; border: none; color: #0F792C; font-size: 11px; font-weight: 600; cursor: pointer; text-decoration: underline; padding: 0;">Create Free Account</button>
                    </div>
                `;
            }

            const userInfoContainer = document.getElementById("userInfo");
            if (userInfoContainer) {
                userInfoContainer.innerHTML = userProfileHtml;
                const inlineLogout = document.getElementById("inlineLogout");
                if (inlineLogout) {
                     inlineLogout.onclick = () => {
                        chrome.storage.local.remove(["authToken", "user"], () => {
                            showAuthScreen();
                        });
                    };
                }
            }
            
            if (msg) {
                 msg.textContent = "Lead Buddy is active. Ready to organize contacts.";
                 msg.style.color = "";
                 msg.style.display = "block";
            }

            // Button Logic based on Subscription
            if (actionButton) {
                actionButton.disabled = false;
                actionButton.title = "";
                actionButton.style.display = "inline-flex"; // Always show analyze
                actionButton.onclick = () => {
                    isAppending = false; // Fresh analysis
                    analyzePageForLeads(tab.id, resultsTable);
                };
            }

            const appendBtn = document.getElementById("appendActionButton");
            if (appendBtn) {
                 // Append might be a pro feature? Requirement doesn't say. 
                 // It says "show 2 btns... other case show all 4".
                 // The 4 are: Analyze, Export, Download, Clear. 
                 // Append is hidden in current HTML comments anyway.
                 appendBtn.style.display = "none";
            }

            if (downloadCsvButton) {
                downloadCsvButton.style.display = "block"; // Always show download
                downloadCsvButton.disabled = savedLeads.length === 0;
                downloadCsvButton.onclick = async () => {
                    if (savedLeads.length === 0) {
                        document.getElementById("message").textContent = "No contacts to download.";
                        return;
                    }
                    
                    // Pre-fill with current search query
                    const query = await extractCurrentSearchQuery();
                    openDownloadModal(query || "leads-export");
                };
            }
            
            // Clear Data Button - "Other case show all 4" -> This is one of the 4?
            // "Analyze page and donwload csv" (2 buttons) vs "All 4 buttons".
            // So Clear Data and Export are the ones to hide if not subscribed?
            // I will assume Clear stays? Or maybe Clear is the 4th?
            // Buttons: Analyze, Export, Download, Clear. 
            // If !Subscribed: Show Analyze, Download. Hide Export, Clear.
            
            const clearDataButton = document.getElementById("clearDataButton");
            if (clearDataButton) {
                clearDataButton.style.display = "block"; // Always show
                clearDataButton.disabled = savedLeads.length === 0;
                clearDataButton.onclick = async () => {
                    if (confirm("Clear all saved contacts? This action cannot be undone.")) {
                        await clearAllData();
                        document.getElementById("message").textContent = "All contacts cleared successfully.";
                        document.getElementById("message").style.color = "#0F792C";
                    }
                };
            }
            
            if (exportDbButton) {
                exportDbButton.style.display = user ? "block" : "none"; // Hide if guest
                const { authToken } = await chrome.storage.local.get(["authToken"]);
                exportDbButton.disabled = !authToken || savedLeads.length === 0;
                updateExportBtnIcon(exportDbButton, isSubscribed);
                
                exportDbButton.onclick = () => {
                    if (!isSubscribed) {
                        openUpgradeModal();
                    } else {
                        exportToDb(resultsTable);
                    }
                };
            }
            
            if (filenameInput) filenameInput.style.display = "block"; // Keep filename input? Maybe hide too? I'll keep it.

            // Refresh recommendations if query changed
            const newQuery = await extractCurrentSearchQuery();
            if (newQuery && currentRecommendations && newQuery !== currentRecommendations.searchQuery) {
                handleRecommendations(savedLeads);
            } else if (newQuery && !currentRecommendations) {
                handleRecommendations(savedLeads);
            }

            const clearLink = document.getElementById("clearDataLink");
            if (clearLink && savedLeads.length > 0) clearLink.style.display = "block";

        } else {
            // NOT ON MAPS
            showDashboardView(user);
        }
    });
}

function showDashboardView(user) {
    const userInfoContainer = document.getElementById("userInfo");
    if (userInfoContainer) userInfoContainer.innerHTML = "";
    
    // Hide the controls since we aren't on Maps
    const actionButton = document.getElementById("actionButton");
    if (actionButton) {
        actionButton.style.display = "none";
    }
    const downloadCsvButton = document.getElementById("downloadCsvButton");
    if (downloadCsvButton) downloadCsvButton.style.display = "none";
    const exportDbButton = document.getElementById("exportDbButton");
    if (exportDbButton) exportDbButton.style.display = "none";
    const filenameInput = document.getElementById("filenameInput");
    if (filenameInput) filenameInput.style.display = "none";

    // Check Subscription Status (Logic duplicated from initializeLeadOrganizer)
    const isSubscribed = user && (user.isSubscription || user.isSubscribed);

    const clearDataButton = document.getElementById("clearDataButton");
    if (clearDataButton) {
        // Show if has data (regardless of sub)
        clearDataButton.style.display = (savedLeads.length > 0) ? "block" : "none";
        clearDataButton.disabled = savedLeads.length === 0;
        clearDataButton.onclick = async () => {
             if (confirm("Clear all saved contacts? This action cannot be undone.")) {
                 await clearAllData();
                 document.getElementById("message").textContent = "All contacts cleared successfully.";
                 document.getElementById("message").style.color = "#0F792C";
                 // Re-run this view update to hide the button
                 showDashboardView(user);
             }
        };
    }
    
    // Also handle the clear text link if it exists
    const clearLink = document.getElementById("clearDataLink");
    if (clearLink) {
        clearLink.style.display = (savedLeads.length > 0) ? "block" : "none";
        clearLink.onclick = async (e) => {
            e.preventDefault();
            if (confirm("Clear all scraped results?")) {
                await clearAllData();
                showDashboardView(user);
            }
        };
    }

    let userProfileHtml = '';
    if (user) {
        userProfileHtml = `
            <div style="margin: 0 auto 25px; max-width: 280px; text-align: center;">
                <div style="width: 80px; height: 80px; background: #fdfdfb; border: 5px solid #0F792C; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; box-shadow: 0 8px 24px rgba(15, 121, 44, 0.15); padding: 3px; overflow: hidden;">
                    <img src="/icons/avatar.png" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; object-position: center 1px;">
                </div>
                <h3 style="font-size: 18px; color: #1a202c; margin-bottom: 4px; font-weight: 700;">${user.name || "Lead Buddy User"}</h3>
                <p style="font-size: 13px; color: #718096; margin-bottom: 0;">${user.email}</p>
                <p style="font-size: 11px; color: ${isSubscribed ? '#0F792C' : '#e53e3e'}; font-weight: 600; margin-bottom: 8px;">
                    ${isSubscribed ? 'Premium Plan' : 'Free Plan'}
                </p>
            </div>
        `;
    } else {
        userProfileHtml = `
            <div style="margin: 0 auto 25px; max-width: 280px; text-align: center;">
                <div style="width: 80px; height: 80px; background: #fdfdfb; border: 5px solid #0F792C; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; box-shadow: 0 8px 24px rgba(15, 121, 44, 0.15); padding: 3px; overflow: hidden;">
                    <img src="/icons/avatar.png" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; object-position: center 1px;">
                </div>
                <h3 style="font-size: 18px; color: #1a202c; margin-bottom: 4px; font-weight: 700;">Guest User</h3>
                <p style="font-size: 11px; color: #718096; font-weight: 600; margin-bottom: 8px;">
                    Free Plan
                </p>
            </div>
        `;
    }

    document.getElementById("message").innerHTML = `
        <div style="padding: 10px 0; text-align: center;">
            ${userProfileHtml}
            ${!user ? '<p style="font-size: 16px; font-weight: 600; color: #4a5568; margin-bottom: 20px;">Welcome to Lead Buddy</p>' : ''}
            <button id="openDashboard" class="maps-link-button" style="cursor: pointer; margin-bottom: 20px;">
                Open My Lead Dashboard
            </button>
            <p style="margin-top: -10px; margin-bottom: 20px;"><button id="inlineLogoutMain" style="background: none; border: none; color: ${user ? '#ff4444' : '#0F792C'}; font-size: 12px; font-weight: 600; cursor: pointer; text-decoration: underline;">${user ? 'Logout from Account' : 'Create Free Account'}</button></p>
            <p style="font-size: 12px; color: #a0aec0; max-width: 240px; margin: 0 auto; line-height: 1.5;">
                To organize contacts, search for targets.
            </p>
        </div>
    `;
    
    const dashboardBtn = document.getElementById("openDashboard");
    if (dashboardBtn) {
        dashboardBtn.onclick = () => {
            chrome.tabs.create({ url: DASHBOARD_LINK });
        };
    }

    const inlineLogoutMain = document.getElementById("inlineLogoutMain");
    if (inlineLogoutMain) {
        inlineLogoutMain.onclick = () => {
            chrome.storage.local.remove(["authToken", "user"], () => {
                showAuthScreen();
            });
        };
    }
}

/* -------------------------------------------------------
   ANALYZE PAGE FOR BUSINESS CONTACTS
------------------------------------------------------- */
async function analyzePageForLeads(tabId, resultsTable) {
    isAnalyzing = true;
    // Reset stop signal for new analysis
    await chrome.storage.local.set({ shouldStopScraping: false });
    
    const msg = document.getElementById("message");
    msg.textContent = "🔍 Initiating automated extraction... This may take a minute.";
    msg.style.color = "blue";
    
    // Reset progress counter
    const progressText = document.getElementById("extractionProgressText");
    if (progressText) progressText.textContent = "0";
    
    const overlay = document.getElementById("analyzingOverlay");
    const stopBtn = document.getElementById("stopAnalyzeButton");
    
    if (overlay) {
        overlay.style.display = "flex";
        window.scrollTo(0, 0);
        document.body.classList.add('no-scroll');
    }
    if (stopBtn) {
        stopBtn.disabled = false;
        stopBtn.textContent = "Stop Scraping";
        stopBtn.onclick = async () => {
            stopBtn.disabled = true;
            stopBtn.textContent = "Stopping...";
            await chrome.storage.local.set({ shouldStopScraping: true });
        };
    }

    try {
        // 1. Inject the core script (defines LeadBuddy namespace and functions)
        await chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['organizer.js']
        });

        // 2. Execute the automated scroll & extract process
        // We await the result directly from the tab
        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: async () => {
                // Determine max results based on subscription if needed? 
                // For now sticking to 50-100 to be safe and efficient.
                return await window.LeadBuddy.processLeadsOnPage();
            }
        });

        // Chrome runtime error check
        if (chrome.runtime.lastError) {
            stopAnalyzingUI();
            msg.textContent = "Error: " + chrome.runtime.lastError.message;
            return;
        }

        // Handle the results
        if (typeof handleAnalysisResults === 'function') {
            handleAnalysisResults(results, resultsTable);
        } else {
            msg.textContent = "Error: UI handler missing.";
            stopAnalyzingUI();
        }

    } catch (err) {
        console.error("Analysis failed:", err);
        
        let errorMessage = "Process interrupted.";
        if (err.message) {
            if (err.message.includes("Cannot access")) {
                errorMessage = "Access denied. Please ensure you have allowed the extension to access this page.";
            } else {
                errorMessage = "Error: " + err.message;
            }
        }
        
        msg.textContent = errorMessage + " Ensure you are on a Google Maps search results page.";
        stopAnalyzingUI();
    }
}



/* -------------------------------------------------------
   EXPORT MODAL SETUP
------------------------------------------------------- */
function setupExportModal() {
    exportModalElements.modal = document.getElementById('exportModal');
    exportModalElements.select = document.getElementById('searchStringSelect');
    exportModalElements.newInput = document.getElementById('newSearchInput');
    exportModalElements.newButton = document.getElementById('newSearchButton');
    exportModalElements.cancel = document.getElementById('cancelExportButton');
    exportModalElements.confirm = document.getElementById('confirmExportButton');
    exportModalElements.close = document.getElementById('closeExportModal');
    exportModalElements.error = document.getElementById('exportModalError');

    if (!exportModalElements.modal) {
        return;
    }

    exportModalElements.newButton.addEventListener('click', (event) => {
        event.preventDefault();
        setNewSearchMode(!usingNewSearchString);
    });

    exportModalElements.select.addEventListener('change', () => {
        if (exportModalElements.select.value) {
            setNewSearchMode(false);
            clearExportModalError();
        }
    });

    exportModalElements.cancel.addEventListener('click', (event) => {
        event.preventDefault();
        closeExportModal();
    });

    exportModalElements.close.addEventListener('click', (event) => {
        event.preventDefault();
        closeExportModal();
    });

    exportModalElements.confirm.addEventListener('click', handleConfirmExport);

    exportModalElements.modal.addEventListener('click', (event) => {
        if (event.target === exportModalElements.modal) {
            closeExportModal();
        }
    });

    exportModalElements.newInput.addEventListener('input', () => {
        if (usingNewSearchString) {
            clearExportModalError();
        }
    });
}

/* -------------------------------------------------------
   GENERATE CSV FROM DATA ARRAY
------------------------------------------------------- */
function generateCsvFromData(data) {
    if (!data || data.length === 0) return "";
    
    // CSV Headers
    const headers = ["Title", "Rating", "Reviews", "Phone", "Industry", "Address", "Website", "Google Maps Link"];
    const headerRow = headers.map(h => `"${h}"`).join(",");
    
    // CSV Rows
    const dataRows = data.map(item => {
        return [
            item.title || "",
            item.rating || "",
            item.reviewCount || item.reviews || "",
            item.phone || "",
            item.industry || "",
            item.address || "",
            item.companyUrl || "",
            item.href || ""
        ].map(value => `"${value}"`).join(",");
    });
    
    return [headerRow, ...dataRows].join("\n");
}

/* -------------------------------------------------------
   TABLE → CSV
------------------------------------------------------- */
function tableToCsv(table) {
    const rows = [...table.querySelectorAll("tr")];
    return rows
        .map((row) =>
            [...row.children].map((td) => `"${td.textContent}"`).join(",")
        )
        .join("\n");
}

/* -------------------------------------------------------
   DOWNLOAD CSV
------------------------------------------------------- */
function downloadCsv(csv, filename) {
    const blob = new Blob([csv], { type: "text/csv" });
    const link = document.createElement("a");
    link.download = filename;
    link.href = URL.createObjectURL(blob);
    link.click();
}

/* -------------------------------------------------------
   EXPORT TO DATABASE
------------------------------------------------------- */
async function exportToDb(table) {
    if (savedLeads.length === 0) {
        document.getElementById("message").textContent = "No contacts to export.";
        return;
    }

    pendingExportData = savedLeads.map(item => ({
        title: item.title,
        rating: item.rating,
        reviews: item.reviewCount || item.reviews || "", // Map reviewCount or reviews
        phone: item.phone,
        industry: item.industry,
        address: item.address,
        website: item.companyUrl || item.website || "",
        googleMapsLink: item.href || item.googleMapsLink || ""
    }));

    const { authToken } = await chrome.storage.local.get([
        "authToken"
    ]);

    if (!authToken) {
        document.getElementById("message").textContent = "Please login to export.";
        return;
    }

    exportDefaultSearch = await extractCurrentSearchQuery();
    openExportModal(exportDefaultSearch);
}

async function extractCurrentSearchQuery() {
    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const currentUrl = tabs[0]?.url || "";
        const urlMatch = currentUrl.match(/\/maps\/search\/([^/?]+)/);
        if (urlMatch) {
            return decodeURIComponent(urlMatch[1].replace(/\+/g, ' '));
        }
    } catch (err) {
        console.warn('Could not extract search string:', err);
    }
    return '';
}

function openExportModal(defaultSearch) {
    if (!exportModalElements.modal) {
        document.getElementById("message").textContent = 'Export modal not available.';
        return;
    }

    exportModalElements.modal.style.display = 'flex';
    exportModalElements.newInput.value = defaultSearch || '';
    exportDefaultSearch = defaultSearch || '';
    setNewSearchMode(false);
    clearExportModalError();
    populateSearchStringSelect();
}

async function populateSearchStringSelect() {
    if (!exportModalElements.select) return;

    exportModalElements.select.innerHTML = '<option value="">Loading...</option>';

    try {
        const { authToken, user } = await chrome.storage.local.get(["authToken", "user"]);

        if (!authToken || !user) {
            exportModalElements.select.innerHTML = '<option value="">Login required</option>';
            return;
        }

        const res = await fetch(`${API_BASE_URL}/data/unique/${user._id || user.id}`, {
            headers: { Authorization: `Bearer ${authToken}` }
        });

        const json = await res.json();
        exportModalElements.select.innerHTML = '<option value="">Select a search string</option>';

        if (res.ok && json.success && Array.isArray(json.data) && json.data.length > 0) {
            json.data.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                const countLabel = typeof item.count === 'number' ? ` (${item.count})` : '';
                option.textContent = `${item.searchString}${countLabel}`;
                exportModalElements.select.appendChild(option);
            });
        } else {
            const emptyOption = document.createElement('option');
            emptyOption.value = '';
            emptyOption.disabled = true;
            emptyOption.textContent = 'No saved searches yet';
            exportModalElements.select.appendChild(emptyOption);
        }

        exportModalElements.select.disabled = usingNewSearchString;
    } catch (error) {
        console.error('Failed to load search strings:', error);
        exportModalElements.select.innerHTML = '<option value="">Unable to load searches</option>';
        showExportModalError('Failed to load search strings.');
    }
}

function setNewSearchMode(enabled) {
    usingNewSearchString = enabled;

    if (!exportModalElements.newInput || !exportModalElements.select) {
        return;
    }

    exportModalElements.newInput.disabled = !enabled;
    exportModalElements.select.disabled = enabled;
    exportModalElements.newButton.textContent = enabled ? 'Use Existing Search' : 'New Search String';

    if (!enabled) {
        exportModalElements.newInput.value = exportDefaultSearch || '';
    } else {
        exportModalElements.newInput.focus();
    }

    clearExportModalError();
}

function showExportModalError(message) {
    if (exportModalElements.error) {
        exportModalElements.error.textContent = message;
    }
}

function clearExportModalError() {
    if (exportModalElements.error) {
        exportModalElements.error.textContent = '';
    }
}

function setModalSubmitting(isSubmitting) {
    if (!exportModalElements.confirm) return;
    exportModalElements.confirm.disabled = isSubmitting;
    exportModalElements.confirm.textContent = isSubmitting ? 'Saving...' : 'Save';
}

function closeExportModal() {
    if (!exportModalElements.modal) return;
    exportModalElements.modal.style.display = 'none';
    pendingExportData = [];
    setModalSubmitting(false);
    setNewSearchMode(false);
    clearExportModalError();
}

async function handleConfirmExport(event) {
    event.preventDefault();

    if (!pendingExportData.length) {
        showExportModalError('No saved contacts available.');
        return;
    }

    if (usingNewSearchString && exportModalElements.newInput.disabled) {
        setNewSearchMode(true);
    }

    if (!usingNewSearchString && !exportModalElements.select.value) {
        showExportModalError('Please select a search string or add a new one.');
        return;
    }

    if (usingNewSearchString && !exportModalElements.newInput.value.trim()) {
        showExportModalError('Please enter a search string.');
        return;
    }

    setModalSubmitting(true);
    clearExportModalError();

    try {
        let successMessage = '';

        if (usingNewSearchString) {
            successMessage = await createNewSearchRecord(exportModalElements.newInput.value.trim());
        } else {
            successMessage = await appendToExistingSearch(exportModalElements.select.value);
        }

        document.getElementById("message").textContent = successMessage || `✅ Exported ${pendingExportData.length} contacts!`;
        closeExportModal();
    } catch (error) {
        console.error('Export error:', error);
        showExportModalError(error.message || 'Failed to export data.');
    } finally {
        setModalSubmitting(false);
    }
}

async function createNewSearchRecord(searchString) {
    const { authToken, user } = await chrome.storage.local.get(["authToken", "user"]);

    if (!authToken || !user) {
        throw new Error('Please login to export.');
    }

    const res = await fetch(`${API_BASE_URL}/data`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({
            userId: user._id || user.id,
            searchString,
            data: pendingExportData
        })
    });

    const json = await res.json();

    if (!res.ok) {
        throw new Error(json.message || 'Export failed.');
    }

    return json.message || `✅ Exported ${pendingExportData.length} records!`;
}

async function appendToExistingSearch(recordId) {
    const { authToken } = await chrome.storage.local.get(["authToken"]);

    if (!authToken) {
        throw new Error('Please login to export.');
    }

    const res = await fetch(`${API_BASE_URL}/data/${recordId}/append`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({
            entries: pendingExportData
        })
    });

    const json = await res.json();

    if (!res.ok || !json.success) {
        throw new Error(json.message || 'Failed to save data.');
    }

    return json.message || 'Data appended successfully';
}

/* -------------------------------------------------------
   UPGRADE MODAL SETUP
------------------------------------------------------- */
function setupUpgradeModal() {
    upgradeModalElements.modal = document.getElementById('upgradeModal');
    upgradeModalElements.upgradeBtn = document.getElementById('upgradePlanButton');
    upgradeModalElements.cancelBtn = document.getElementById('cancelUpgradeButton');
    upgradeModalElements.closeBtn = document.getElementById('closeUpgradeModal');

    if (!upgradeModalElements.modal) return;

    upgradeModalElements.upgradeBtn.onclick = () => {
        chrome.tabs.create({ url: DASHBOARD_LINK + '/subscription' });
        closeUpgradeModal();
    };

    upgradeModalElements.cancelBtn.onclick = () => {
        closeUpgradeModal();
    };

    upgradeModalElements.closeBtn.onclick = () => {
        closeUpgradeModal();
    };

    upgradeModalElements.modal.onclick = (event) => {
        if (event.target === upgradeModalElements.modal) {
            closeUpgradeModal();
        }
    };
}

function openUpgradeModal() {
    if (upgradeModalElements.modal) {
        upgradeModalElements.modal.style.display = 'flex';
    }
}

function closeUpgradeModal() {
    if (upgradeModalElements.modal) {
        upgradeModalElements.modal.style.display = 'none';
    }
}

/* -------------------------------------------------------
   DOWNLOAD MODAL SETUP
------------------------------------------------------- */
function setupDownloadModal() {
    downloadModalElements.modal = document.getElementById('downloadModal');
    downloadModalElements.input = document.getElementById('modalFilenameInput');
    downloadModalElements.confirmBtn = document.getElementById('confirmDownloadButton');
    downloadModalElements.cancelBtn = document.getElementById('cancelDownloadButton');
    downloadModalElements.closeBtn = document.getElementById('closeDownloadModal');

    if (!downloadModalElements.modal) return;

    downloadModalElements.confirmBtn.onclick = () => {
        let filename = downloadModalElements.input.value.trim();
        if (!filename) filename = "leads-export";
        
        // Sanitize and add extension
        filename = filename.replace(/[^a-z0-9]/gi, "_").toLowerCase();
        if (!filename.endsWith(".csv")) filename += ".csv";

        const csv = generateCsvFromData(savedLeads);
        downloadCsv(csv, filename);
        closeDownloadModal();
    };

    downloadModalElements.cancelBtn.onclick = () => {
        closeDownloadModal();
    };

    downloadModalElements.closeBtn.onclick = () => {
        closeDownloadModal();
    };

    downloadModalElements.modal.onclick = (event) => {
        if (event.target === downloadModalElements.modal) {
            closeDownloadModal();
        }
    };
    
    // Allow enter key to confirm
    downloadModalElements.input.onkeypress = (e) => {
        if (e.key === 'Enter') {
            downloadModalElements.confirmBtn.click();
        }
    };
}

function openDownloadModal(defaultName) {
    if (downloadModalElements.modal) {
        if (downloadModalElements.input) {
            // Clean up default name for input
            const cleanName = defaultName.replace(/[^+/a-z0-9 ]/gi, "").trim() || "leads-export";
            downloadModalElements.input.value = cleanName;
        }
        downloadModalElements.modal.style.display = 'flex';
        setTimeout(() => downloadModalElements.input?.focus(), 100);
    }
}

function closeDownloadModal() {
    if (downloadModalElements.modal) {
        downloadModalElements.modal.style.display = 'none';
    }
}

/* -------------------------------------------------------
   RECEIVE TOKEN FROM WEB DASHBOARD LOGIN
------------------------------------------------------- */
chrome.runtime.onMessage.addListener((req, sender, reply) => {
    if (req.type === "AUTH_SUCCESS") {
        chrome.storage.local.set(
            { authToken: req.token, user: req.user },
            () => {
                console.log("Auth stored");
                window.location.reload();
                reply({ success: true });
            }
        );
        return true;
    }
    
    if (req.type === "EXTRACTION_PROGRESS") {
        const progressText = document.getElementById("extractionProgressText");
        if (progressText) {
            progressText.textContent = req.count;
        }
    }
});

/* -------------------------------------------------------
   GUEST PROMO MODAL SETUP
------------------------------------------------------- */
function setupGuestPromoModal() {
    const modal = document.getElementById('guestPromoModal');
    const closeBtn = document.getElementById('closeGuestPromoModal');
    const createBtn = document.getElementById('promoCreateAccountBtn');

    if (!modal) return;

    if (closeBtn) {
        closeBtn.onclick = () => {
            modal.style.display = 'none';
        };
    }

    if (createBtn) {
        createBtn.onclick = () => {
            const registerUrl = REGISTER_URL;
            chrome.tabs.create({ url: registerUrl });
            modal.style.display = 'none';
        };
    }

    modal.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };
}
